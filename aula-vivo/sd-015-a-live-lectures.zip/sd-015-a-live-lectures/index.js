const express = require('express');

const ping = require('./middlewares/ping')
const hello = require('./middlewares/hello')
const greeting = require('./middlewares/greeting')
const getSimpsons = require('./middlewares/getSimpsons');
const getSimpsonsById =require('./middlewares/getSimpsonById');
const createSimpson = require('./middlewares/createSimpson');
const validadeSimpsonId = require('./middlewares/validateIdSimpson');
const validadeSimpsonByName = require('./middlewares/validateNameSimpson');

const app = express()
app.use(express.json())

app.get("/ping", ping)
app.post("/hello", hello)
app.post("/greeting", greeting)
app.post("/simpsons", validadeSimpsonId, validadeSimpsonByName, createSimpson)
app.get("/simpsons", getSimpsons)
app.get("/simpson/:id", getSimpsonsById)

app.listen(3000, () => console.log('rodando porta 3000'))