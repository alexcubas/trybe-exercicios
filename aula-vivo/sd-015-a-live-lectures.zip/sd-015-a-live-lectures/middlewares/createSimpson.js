const fs = require('fs').promises;

const express = require('express');
const router = express.Router()

async function createSimpson(req, res) {
    // const { id } = req.params;
    const { id, name } = req.body;

    const lido = await fs.readFile(`./simpsons.json`, 'utf-8')

    parseando = JSON.parse(lido)

    const novoSimp = { id, name }

    const salvo = [...parseando, novoSimp]

    reescrevendo = fs.writeFile('./simpsons.json', JSON.stringify(salvo, null, " "))
  
    res.status(201).json({ message: 'Simpson criado com sucesso!' })
 
}

module.exports = createSimpson;
