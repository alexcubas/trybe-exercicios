const express = require('express');
const router = express.Router()

function ping(_req, res) {
  return res.status(200).send("pong!")
} 

router.get('/', ping);

module.exports = ping;