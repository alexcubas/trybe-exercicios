const fs = require('fs').promises;

const express = require('express');
const router = express.Router()

async function getSimpsons(_req, res) {
  const lido = await fs.readFile('./simpsons.json', 'utf-8')
  return res.status(200).json(JSON.parse(lido))
}

router.get('/', getSimpsons);

module.exports = getSimpsons;