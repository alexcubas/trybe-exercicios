const fs = require('fs').promises;

const express = require('express');
const router = express.Router()

async function validadeSimpsonByName(req, res, next) {
    const { name } = req.body;

    const lido = await fs.readFile(`./simpsons.json`, 'utf-8')

    parseando = JSON.parse(lido)

    if (name === "" || name === null) return res.status(500).json({ message: 'Nome é obrigatório'})

    next()
}

module.exports = validadeSimpsonByName;
