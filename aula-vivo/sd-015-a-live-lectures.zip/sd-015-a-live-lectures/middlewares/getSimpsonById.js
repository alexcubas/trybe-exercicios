const fs = require('fs').promises;

const express = require('express');
const router = express.Router()

async function getSimpsonsById(req, res) {
    const { id } = req.params;
    const lido = await fs.readFile(`./simpsons.json`, 'utf-8')
  
    parseando = JSON.parse(lido)
  
    encontrando = parseando.find((v) => v.id === parseInt(id))

    if (typeof encontrando === "undefined") return res.status(404).json({ message: 'Simpson not found!' })
  
    return res.status(200).json(encontrando)
 
}

// router.get('/:id', getSimpsonsById);

module.exports = getSimpsonsById;
