const express = require('express');
const router = express.Router()

function hello(req, res) {
  const { name } = req.body;

  res.status(201).json({ message: `Hello, ${name}!` })
}

router.post('/', hello);

module.exports = hello;