const fs = require('fs').promises;

const express = require('express');
const router = express.Router()

async function validadeSimpsonId(req, res, next) {
    const { id } = req.body;

    const lido = await fs.readFile(`./simpsons.json`, 'utf-8')

    parseando = JSON.parse(lido)

    const ximira = parseando.find((r) => r.id === parseInt(id))

    if(typeof ximira !== "undefined") return res.status(500).json({ message: 'Não é possível cadastrar esse simpson!' })
    
    next()
}

module.exports = validadeSimpsonId;
